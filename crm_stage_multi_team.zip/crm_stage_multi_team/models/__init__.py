# -*- coding: utf-8 -*-
from . import crm_stage_m2m
from . import crm_lead_stage_logic
